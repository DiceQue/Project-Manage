/**
 * Created by SharathBhargav on 19-05-2017.
 */
          var config = {
              apiKey: "AIzaSyDIZUpy8OHRz6GDEmyANHV6X0MlLLx_iFo",
              authDomain: "athithi-167215.firebaseapp.com",
              databaseURL: "https://athithi-167215.firebaseio.com",
              projectId: "athithi-167215",
              storageBucket: "athithi-167215.appspot.com",
              messagingSenderId: "568934962731"
          };
          firebase.initializeApp(config);


    //firebase.auth().signInAnonymously().catch(function(error) {
    //    // Handle Errors here.
    //    var errorCode = error.code;
    //    console.log(errorCode);
    //
    //    var errorMessage = error.message;
    //    console.log(errorMessage);
    //    // ...
    //});



  var signedIn;
var pGID;

console.log("sign in login>>"+signedIn);