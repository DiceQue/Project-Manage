/**
 * Created by SharathBhargav on 20-05-2017.
 */
var provider = new firebase.auth.GoogleAuthProvider();


var mega=document.getElementById('megaButton');

firebase.auth().onAuthStateChanged(function(user) {
    if (user) {

        mega.style.visibility='block';
        // User is signed in.
    } else {
        // No user is signed in.
        mega.style.visibility='none';
        firebase.auth().signInWithPopup(provider).then(function(result) {
            // This gives you a Google Access Token. You can use it to access the Google API.
            var token = result.credential.accessToken;
            // The signed-in user info.
            console.log("token:"+token);
            var user = result.user;
            mega.style.visibility='block';
            signedIn=user.email;

            console.log("user>>"+signedIn);
            // ...
        }).catch(function(error) {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            console.log(errorMessage);
            // The email of the user's account used.
            var email = error.email;
            // The firebase.auth.AuthCredential type that was used.
            var credential = error.credential;
            // ...
        });
    }
});

