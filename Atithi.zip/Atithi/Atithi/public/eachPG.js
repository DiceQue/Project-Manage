/**
 * Created by SharathBhargav on 07-05-2017.
 */

//var url = document.location.href.toString();
//var id;
//id=decodeURI(url);
//id=id.substring(id.lastIndexOf('=')+1);
var id=sessionStorage.getItem("lastname");
var firebaseref=firebase.database().ref();

firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
        window.onload=display();
    } else {
        // No user is signed in.
    }
});

 function display()
 {



     console.log("PGid="+id);
     var mainDiv=document.getElementById('main');
     firebase.database().ref('/Staysafe/pglist/'+id).once('value').then(function(snapshot) {
        console.log(snapshot.child('name').val());
         var name=document.createElement('p');
         var address=document.createElement('p');
         var facilities=document.createElement('p');
         var sharing=document.createElement('div');
         var lodging=document.createElement('p');
         var displayImg=document.createElement('img');
         var gender=document.createElement('p');
         var phno1=document.createElement('p');
         var phno2=document.createElement('p');
         var imgDiv=document.createElement('div');

         var ratingStatus=document.createElement('p');
         imgDiv.setAttribute('horizontal', '');
         imgDiv.setAttribute('layout', '');
         imgDiv.style.border="3px solid black";





            var approveButton=document.createElement('button');

        approveButton.type='submit';
        approveButton.className='btn btn-lg btn-success btn-block';
         approveButton.style.display='block';
         approveButton.style.height="40px";
         approveButton.innerHTML='Approve PG';
        approveButton.style.marginTop='20px';
         approveButton.onclick=function()
         {
             var updates = {};
             updates['/Staysafe/pglist/'+id+'/approved'] =1;
             firebase.database().ref().update(updates);
             alert("PG approved");

         };



         var delet=document.createElement('button');
         delet.type='submit';
         delet.className='btn btn-lg btn-danger btn-block';
         delet.style.display='block';
         delet.style.height="40px";
         delet.innerHTML='Delete PG';
         delet.style.marginTop='20px';


         delet.onclick=function()
         {
            var con=confirm("Are you sure you want to delete this PG");
             if(con==true)
             {
                 var updates = {};
                 updates['/Staysafe/pglist/'+id+'/approved'] =0;
                 firebase.database().ref().update(updates);
                 alert("PG disapproved and removed from listing");
             }

         };



         var rating=document.createElement('button');

         rating.type='submit';
         rating.className='btn btn-lg btn-warning btn-block';
         rating.style.display='block';
         rating.style.height="40px";
         rating.innerHTML='Change rating of PG';
         rating.style.marginTop='20px';


        rating.onclick=function()
         {
           var newRating=prompt("Enter the rating of PG","");
             newRating=parseFloat(newRating);

                 var updates = {};
                 updates['/Staysafe/pglist/'+id+'/rating'] =newRating.toString();
                 firebase.database().ref().update(updates);
                 alert("PG rating changed");


         };





         snapshot.child('photos').forEach(
             function(picSnapshot)
             {
                 var imgView=document.createElement('img');
                 imgView.src=picSnapshot.val();
                 imgView.style.border="3px solid red";
                 imgDiv.appendChild(imgView);

             }
         );
         name.innerHTML="Name:"+snapshot.child('name').val();
         name.style.textAlign="center";
         name.style.textEffect="bold";
         var add=snapshot.child('address').val().toString();
         address.innerHTML="Address:"+add.replace(/\$/g,' , ').replace(/@/g,"<br>");
         displayImg.src=snapshot.child('displaypic').val();
         gender.innerHTML="Gender:"+snapshot.child('gender').val();
         phno1.innerHTML="Phone no1:"+snapshot.child('phno1').val();
         phno2.innerHTML="Phone no2:"+snapshot.child('phno2').val();
         ratingStatus.innerHTML="Rating:   "+snapshot.child('rating').val()+'\n\n';


        var fac="";
         facilities.innerHTML="Facilities:";
         snapshot.child('facilities').forEach(
             function(facSnapshot){
                 if(facSnapshot.val()==1)
                 {
                     fac+=facSnapshot.getKey()+",";
                 }
             }

         );
         var shr="";

         sharing.setAttribute('horizontal', '');
         sharing.setAttribute('layout', '');
         sharing.style.display = "block";
         sharing.setAttribute('white-space','nowrap');
         snapshot.child('sharing').forEach(
             function (shareSnapshot) {
                 var total=document.createElement('div');
                 total.style.border="2px solid red";
                 total.style.maxWidth="120px";
                 var num=document.createElement('p');
                 num.style.textAlign="center";
                 var avail=document.createElement('p');
                 var cost=document.createElement('p');
                 num.innerHTML=shareSnapshot.getKey();
                 avail.innerHTML="Availability:"+shareSnapshot.child('availability').val();
                 cost.innerHTML="Cost:"+shareSnapshot.child('cost').val();
                 total.appendChild(num);
                 total.appendChild(avail);
                 total.appendChild(cost);
                 sharing.appendChild(total);

             }
         )
         facilities.innerHTML+=fac.substring(0,fac.length-1);
         mainDiv.appendChild(name);
         mainDiv.appendChild(displayImg);
         mainDiv.appendChild(address);
         mainDiv.appendChild(gender);
         mainDiv.appendChild(phno1);
         mainDiv.appendChild(phno2);
         mainDiv.appendChild(sharing);
         mainDiv.appendChild(facilities);
         mainDiv.appendChild(ratingStatus);


         mainDiv.appendChild(imgDiv);

         mainDiv.appendChild(approveButton);
        mainDiv.appendChild(delet);

         mainDiv.appendChild(rating);
     });
 }
