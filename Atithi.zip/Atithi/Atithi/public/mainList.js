/**
 * Created by SharathBhargav on 07-05-2017.
 */


var firebaseref=firebase.database().ref();



firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
        console.log("user>>"+user.toString());
        console.log("user1>>"+user.email);
        window.onload=loadList();

        // User is signed in.
    } else {
        // No user is signed in.
    }
});


function loadList()
{



    var list=document.getElementById('list');
    var loading=document.getElementById('loading');

    firebase.database().ref('/Staysafe/pglist').once('value').then(function(snapshot) {



        snapshot.forEach(
            function (childSnapshot) {
                var block1=document.createElement('div');
                var text1=document.createElement('p');
                var text2=document.createElement('p');
                var text3=document.createElement('p');
                var totalcount=document.createElement('p');
                var approvedCount=document.createElement('p');
                var approved=document.createElement('p');
                var button=document.createElement('button');

                button.type='submit';
                var name=childSnapshot.getKey().toString();
                var lastIndex=name.lastIndexOf('_');
                var ownerId=name.substr(lastIndex+1);
                var ownerName= firebase.database().ref('/Staysafe/ownerlist/'+ownerId).once('value').then(function(ownerSnap)
                {

                    text3.innerHTML="Owner name:"+ownerSnap.child('Name').val();
                });


                totalcount.innerHTML="Total pre booking count:       "+childSnapshot.child('totalcount').val();
                approvedCount.innerHTML="Approved pre booking by owner:         "+childSnapshot.child('appprovedcount').val();
                var app=childSnapshot.child('approved').val();
                if(app=="0") {
                    approved.innerHTML = "Not approved";
                    block1.style.backgroundColor="#FF000045";
                    button.className='btn btn-lg btn-success btn-block';
                }
                else {
                    approved.innerHTML = "Approved";
                    block1.style.backgroundColor="#00FF0045";
                    button.className='btn btn-lg btn-danger btn-block';
                }

              text1.innerHTML="Name:"+childSnapshot.child('name').val();
                var add=childSnapshot.child('address').val().toString();
                text2.innerHTML="Address:"+add.replace(/\$/g,' , ').replace(/@/g,"<br>");
                button.onclick=function()
                {


                    sessionStorage.setItem("lastname", childSnapshot.getKey());
                  //  document.location.href="https://athithi-167215.firebaseapp.com/eachPG.html?myvar="+encodeURIComponent(childSnapshot.getKey());

                    window.location="eachPG.html";
                };


              button.style.display='block';
                button.style.height="40px";
                button.innerHTML="Click to view PG";

                block1.appendChild(text1);

                block1.appendChild(text3);
                block1.appendChild(text2);
                block1.appendChild(totalcount);
                block1.appendChild(approvedCount);
                block1.appendChild(approved);
                block1.appendChild(button);
                block1.style.border="1px solid blue";

                list.appendChild(block1);

            }
        )
        loading.style.visibility='hidden';
        // ...
    });
  //

}